var express = require('express');
var passport = require('passport');
var BasicStrategy = require('passport-http').BasicStrategy;
var layouts = require('handlebars-layouts');
var hbs = require('hbs');
var fs = require('fs');

if(process.env.NODE_ENV != 'production') process.env.PORT = 3001;

layouts.register(hbs.handlebars);
// Inclui todos os layouts
var path = './views';
fs.readdirSync(path).filter(function(entry){
  file_name = [path,entry].join('/');
  if(entry.match(/^layout_.*\.hbs/)){
    hbs.handlebars.registerPartial('layout_positivacao', fs.readFileSync(file_name, 'utf8'));
  }
});

var app = express();

app.set('view engine','html');
app.set('views','./views');
app.engine('html',require('hbs').__express);

// Configuração do BasicStrategy
app.use(passport.initialize());
passport.use(
  new BasicStrategy(function(username,password,done){
    if(username.valueOf() == 'minhaoi' && password.valueOf() == 'polidoro'){
      return done(null,true);
    }else{
      return done(null,false);
    }
  })
);

// Serve as assets na pasta './assets'
app.use(express.static('./assets'));

// Autentica e renderiza o arquivo .html e passa a Query String como parâmetros pro Handlebars
app.use('*',passport.authenticate('basic',{session:false}),function(req,res){
  var parts = req.originalUrl.split('/');
  var filename  = parts.pop();
  filename = filename.split('?')[0];
  var path = './views/'+filename+'.html';
  if(fs.existsSync(path)){
    res.render(filename+'.html',req.query);
  }else{
    res.render('index.html');
  }
});

// Error handler
app.use(function(err,req,res,next){
  res.status(err.status || 500).json(err.message);
});

app.listen(process.env.PORT,function(){
  console.log('Server listening to port '+process.env.PORT);
});
