# ExpressJS
O projeto contém um miniservidor ExpressJS (https://www.npmjs.com/package/express)
e roda na porta 3000 em desenvolvimento.

# Handlebars
Utiliza Handlebars (http://handlebarsjs.com/) para os processar os templates e o
pacote Handlebars para Express é o HBS (https://www.npmjs.com/package/hbs).

# Heroku
O projeto está publicado no Heroku na url:
https://minhaoi-telas.herokuapp.com/

# BasicAuth
Login: minhaoi
Senha: polidoro

# Node-Sass
Recomenda-se utilizar o Node-Sass para compilar os CSS.
